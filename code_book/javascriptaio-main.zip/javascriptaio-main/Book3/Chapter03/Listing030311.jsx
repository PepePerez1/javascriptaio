class Message extends React.PureComponent {
  render() {
    return <h1>Hi, {this.props.firstName}</h1>;
  }
}
