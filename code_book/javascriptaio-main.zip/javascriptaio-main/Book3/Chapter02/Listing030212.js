export const headline = {
  fontSize: '200%',
  color: '#333',
};
export const authorName = {
  fontWeight: 'bold',
};
export const bodyText = {
  color: '#000',
};
