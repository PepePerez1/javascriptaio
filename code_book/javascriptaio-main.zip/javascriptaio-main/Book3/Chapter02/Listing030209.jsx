[
  {
    customerId: '1',
    address: '234 Pine Street',
    city: 'Pinewood',
    state: 'IL',
  },
  {
    customerId: '2',
    address: '456 Elm Street',
    city: 'Elmwood',
    state: 'MI',
  },
  {
    customerId: '3',
    address: '678 Maple Street',
    city: 'Maplewood',
    state: 'OH',
  },
  {
    customerId: '4',
    address: '901 Chestnut Street',
    city: 'Chestnut',
    state: 'SC',
  },
];
