function TopNavBar() {
  return (
    <nav>
      <ul>
        <li>All</li>
        <li>News</li>
        <li>Videos</li>
        <li>Images</li>
        <li>Books</li>
        <li>More</li>
      </ul>
    </nav>
  );
}
export default TopNavBar;
