function SearchBox() {
  return (
    <div>
      <input type="text" placeholder="Search Google or type a URL" />
    </div>
  );
}
export default SearchBox;
