<button onClick={() => increment(2)}>Add 2</button>;
