# Gamelet

A starter program for writing JavaScript games.

## Usage

1. Include gamelet.js in an HTML document containing an
   element with an id of 'ball'.

```html
<div id="ball">@</div>
<script src="gamelet.js" />
```

2. The script will detect when the left or right arrow
   keys are pressed and will move the ball element
   accordingly.
