// oregonInfo.js

export const stateName = 'Oregon';
export const capitalCity = 'Salem';
export const stateBird = 'Western meadowlark';

export default function getStateInfo() {
  return { stateName, capital, stateBird };
}
