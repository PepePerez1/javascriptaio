export function addOne(input) {
  return input + 1;
}
