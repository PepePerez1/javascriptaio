const myLocation = {
  city: {
    id: 2643743,
    name: 'London',
    coord: {
      lon: -0.1258,
      lat: 51.5085,
    },
    country: 'GB',
    population: 9820000,
    timezone: 3600,
  },
};
