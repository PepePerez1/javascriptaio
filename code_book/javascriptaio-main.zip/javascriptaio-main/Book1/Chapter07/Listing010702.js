class Pet {
  constructor(name, type) {
    this.name = name;
    this.type = type;
  }
}

const ourDog = new Pet('Chauncey', 'AmStaff');
