for (const property in document) {
  console.log(`${property}: ${document[property]}`);
}
