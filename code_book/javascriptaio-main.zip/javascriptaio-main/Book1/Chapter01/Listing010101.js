let normalName = 'Chris';
let javaScriptName = normalName + 'Script';
console.log('Your JavaScript Name is ' + javaScriptName);
