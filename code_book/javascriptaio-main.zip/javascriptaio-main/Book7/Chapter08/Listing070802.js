const dbConfig = {
  url: 'mongodb://localhost:27017',
  dbName: 'mydb',
};
export { dbConfig };
