async function getData() {
  return await fetch('https://nothinghere');
}

getData();
