<script>
    export let message = '';

</script>
<p class="error">{message}</p>
