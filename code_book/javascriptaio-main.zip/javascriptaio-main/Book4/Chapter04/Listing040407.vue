<script setup>
import { reactive } from 'vue';

const state = reactive({ cupsOfCoffee: 0 });
</script>
