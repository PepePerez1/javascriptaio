app.config.globalProperties.appName = 'My Test App';
