<template>
  <h1>
    <slot name="title">No title provided</slot>
  </h1>
  <div>
    <slot name="body">No body provided</slot>
  </div>
</template>
