<script setup>
import Listing0301 from './components/Listing0301.vue';
</script>

<template>
  <Listing0301 />
</template>
