<template>
  <h1>Let's count to 100!</h1>
  <div v-for="i in 100">{{ i }}</div>
</template>
