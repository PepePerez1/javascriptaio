<template>
  <div
    style="
      width: 300px;
      border-radius: 19% 81% 30% 70% / 29% 17% 83% 71%;
      background-image: linear-gradient(to bottom right, red, yellow);
      color: white;
    "
  >
    <slot></slot>
  </div>
</template>
