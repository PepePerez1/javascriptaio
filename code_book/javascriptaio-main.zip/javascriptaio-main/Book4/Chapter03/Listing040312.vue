<template>
  <h1>
    <slot>No content was provided.</slot>
  </h1>
</template>
