<template>
  <h1>No they shouldn't!</h1>
</template>
<style scoped>
h1 {
  border: none;
}
</style>
