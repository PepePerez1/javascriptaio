<template v-slot:title>10 Tips for Keeping Your Pencils Sharpened</template>
<template v-slot:body>
  <p>
    Do you have pencils that get dull after you use them? This problem is more
    common than you might think.
  </p>
</template>
