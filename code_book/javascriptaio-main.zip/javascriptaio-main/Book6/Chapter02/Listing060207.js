function Obstacle({ obstaclePosition }) {
  return <div className="obstacle" style={obstaclePosition}></div>;
}
