export function dogToHumanAge(dogAge) {
  const dogHumanAge = dogAge * 7;
  return dogHumanAge;
}
