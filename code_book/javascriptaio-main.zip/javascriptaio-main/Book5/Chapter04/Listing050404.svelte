<script>
  let message = '';
</script>

<input bind:value={message} />
<p>{message}</p>
