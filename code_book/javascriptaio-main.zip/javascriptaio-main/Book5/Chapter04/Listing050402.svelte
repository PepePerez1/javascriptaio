<script>
  export let value = 0;
</script>

<button on:click {value}>Click Me</button>
