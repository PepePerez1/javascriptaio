<script>
  let error = true;
</script>

{#if error}
  {@html '<b>An error has occurred.</b>'}
{/if}
