<script>
  let error = true;
</script>

<div>
  {error ? '<b>An error has occurred' : ''}
</div>
