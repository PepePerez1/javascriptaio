<!-- PageTitle.svelte -->
<h1>
  <slot>If you see this text, no content was provided.</slot>
</h1>
