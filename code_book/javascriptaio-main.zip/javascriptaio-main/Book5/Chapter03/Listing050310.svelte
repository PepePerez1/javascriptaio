<script>
  import PageTitle from './lib/PageTitle.svelte';
</script>

<PageTitle>How to Use Slots in Svelte</PageTitle>
