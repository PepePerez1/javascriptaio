<script>
  import CatPicture from './lib/CatPicture.svelte';
</script>

<h1>Here are some cat pictures</h1>
<table class="cat-pictures-table">
  <tr>
    <td><CatPicture /></td>
    <td><CatPicture /></td>
    <td><CatPicture /></td>
  </tr>
  <tr>
    <td><CatPicture /></td>
    <td><CatPicture /></td>
    <td><CatPicture /></td>
  </tr>
</table>
