<article>
  <slot name="header">This will be the header text.</slot>
  <slot />
  <slot name="footer">Copyright, All rights reserved, etc.</slot>
</article>
