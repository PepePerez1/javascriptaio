import { readable } from 'svelte/store';

export const store = readable(0);
