<script>
  import { timer } from './stores/timer.js';
</script>

<h1>The current time is: {$timer}</h1>
