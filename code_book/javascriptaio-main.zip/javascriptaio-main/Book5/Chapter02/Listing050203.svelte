<script>
  import MusicPlayer from './MusicPlayer.svelte';
</script>

<MusicPlayer musicStyle="rock" />
<MusicPlayer musicStyle="jazz" />
<MusicPlayer musicStyle="hip hop" />
