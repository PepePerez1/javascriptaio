<script>
  export let musicStyle = undefined;
</script>

<p>Here is some {musicStyle}.</p>
