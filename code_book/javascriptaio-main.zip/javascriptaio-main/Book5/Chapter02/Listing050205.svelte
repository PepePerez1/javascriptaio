<script>
  import BlogPost from './BlogPost.svelte';
</script>

<BlogPost
  blogTitle="Sandwiches are Great"
  blogBody="I just had the best sandwich."
  published={true}
/>
